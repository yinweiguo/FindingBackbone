	parameter(L1=2500,L2=L1,Ny=L1,Nx=Ny-1,m=Nx,n=m)
	parameter(NPMAX=L1*L2/8)
        parameter(REGION=(Ny-2)*(Ny-2))
	logical OUT_BACKBONE, OUT_PERCOL, DEBUG
	parameter(OUT_BACKBONE=.FALSE.)
	parameter(OUT_PERCOL =.FALSE.)
	parameter(DEBUG =.FALSE.)
*	parameter(OUT_BACKBONE=.TRUE.)
*	parameter(OUT_PERCOL =.TRUE.)
*	parameter(DEBUG =.TRUE.)
