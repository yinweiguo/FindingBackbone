#include<stdio.h>

void read_int__(int site[], int *size, int *num, char *s)
{
	FILE *fsample;
        printf("size, num, s = %d %d %s\n", *size, *num, s);

	if((fsample = fopen(s,"rb"))==NULL) {
           printf("error in reading file %s\n",s);
           exit(1);
        }
	fread(site,*size,*num,fsample);
	fclose(fsample);
}
